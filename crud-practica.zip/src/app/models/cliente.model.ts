export class ClienteModel{
    id?: any = '';
    nombre: string ='';
    apellido: string='';
    correo:string='';

    
}